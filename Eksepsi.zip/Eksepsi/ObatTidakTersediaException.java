/* File : ObatTidakTersediaException.java */
/* Deskripsi : Program untuk menunjukkan Exception */
/* Nama/Nim : Kanz Allief Aryaputra/24060122140135 */

package tugas2;
public class ObatTidakTersediaException extends Exception {
    public ObatTidakTersediaException(String message) {
        super(message);
    }
}
